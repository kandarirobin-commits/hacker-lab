<?php
require __DIR__ . '/_bootstrap.php';
require_login();
$user = current_user();

$id = (int)($_GET['id'] ?? $user['id']);

// VULNERABLE ON PURPOSE (challenge: idor-profile): any logged-in user can
// view any other user's profile by id, with no ownership/role check.
// Do not copy this pattern into real code — see README.md for the fix.
$pdo = get_db();
$stmt = $pdo->prepare("SELECT id, username, email, bio, is_admin FROM users WHERE id = ?");
$stmt->execute([$id]);
$profile = $stmt->fetch(PDO::FETCH_ASSOC);

if ($profile && $id !== (int)$user['id']) {
    mark_solved('idor-profile');
}

$page_title = 'Profile';
require __DIR__ . '/../includes/header.php';
?>
<h1>Profile</h1>
<?php if (!$profile): ?>
    <div class="flash error">No user with that id.</div>
<?php else: ?>
    <div class="card">
        <p><strong>Username:</strong> <?= htmlspecialchars($profile['username']) ?></p>
        <p><strong>Email:</strong> <?= htmlspecialchars($profile['email']) ?></p>
        <p><strong>Bio:</strong> <?= htmlspecialchars($profile['bio']) ?></p>
        <?php if ($profile['is_admin']): ?><p><strong>Role:</strong> Administrator</p><?php endif; ?>
    </div>
    <p class="lead">Viewing id=<?= (int)$id ?>. You are logged in as <?= htmlspecialchars($user['username']) ?> (id=<?= (int)$user['id'] ?>).</p>
<?php endif; ?>
<p><a href="/hint.php?challenge=idor-profile">Hint</a></p>
<?php require __DIR__ . '/../includes/footer.php'; ?>
