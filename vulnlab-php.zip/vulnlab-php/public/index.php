<?php
require __DIR__ . '/_bootstrap.php';
$page_title = 'VulnLab-PHP — Challenges';
require __DIR__ . '/../includes/header.php';
?>

<h1>VulnLab-PHP</h1>
<p class="lead">A deliberately vulnerable PHP training app. Pick a challenge, exploit the bug, then check the solution writeup.</p>

<div class="notice">
    Run this only on <code>localhost</code> or an isolated lab network. It contains intentional, unpatched
    vulnerabilities and must never be deployed anywhere internet-reachable.
</div>

<div class="challenge-grid">
<?php foreach (get_challenges() as $id => $c): ?>
    <div class="card">
        <span class="badge difficulty-<?= htmlspecialchars($c['difficulty']) ?>"><?= htmlspecialchars($c['difficulty']) ?></span>
        <span class="badge"><?= htmlspecialchars($c['category']) ?></span>
        <?php if (is_solved($id)): ?><span class="badge solved">✓ Solved</span><?php endif; ?>
        <div>
            <a class="challenge-link" href="<?= htmlspecialchars($c['url']) ?>"><?= htmlspecialchars($c['title']) ?></a>
        </div>
        <p><?= htmlspecialchars($c['description']) ?></p>
        <div class="actions">
            <a href="<?= htmlspecialchars($c['url']) ?>">Open challenge →</a>
            <a href="/hint.php?challenge=<?= urlencode($id) ?>">Hint</a>
            <a href="/solution.php?challenge=<?= urlencode($id) ?>">Solution</a>
        </div>
    </div>
<?php endforeach; ?>
</div>

<h2>Seed accounts</h2>
<p class="lead">For challenges that need a logged-in user, start with: <code>alice / alice123</code> or <code>bob / bobpass</code>. Don't just log in as admin directly — several challenges want you to escalate into that account yourself.</p>

<?php require __DIR__ . '/../includes/footer.php'; ?>
