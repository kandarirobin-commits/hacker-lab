<?php
require __DIR__ . '/_bootstrap.php';
$q = $_GET['q'] ?? '';

if ($q !== '' && (stripos($q, '<script') !== false || stripos($q, 'onerror=') !== false || stripos($q, 'onload=') !== false)) {
    mark_solved('xss-reflected');
}

$page_title = 'Search';
require __DIR__ . '/../includes/header.php';
?>
<h1>Site search</h1>
<p class="lead">Search the (fake) article index. Try the obvious thing with the query box.</p>
<form method="get">
    <label>Query</label>
    <input type="text" name="q" value="<?= isset($_GET['q']) ? htmlspecialchars($_GET['q']) : '' ?>">
    <button type="submit">Search</button>
</form>

<?php if ($q !== ''): ?>
<div class="card">
    <!-- VULNERABLE ON PURPOSE (challenge: xss-reflected): the search term
         is echoed back raw, with no output encoding. Do not copy this
         pattern into real code — see README.md for the fix. -->
    <p>No articles found for: <?= $q ?></p>
</div>
<?php endif; ?>

<p><a href="/hint.php?challenge=xss-reflected">Hint</a></p>
<?php require __DIR__ . '/../includes/footer.php'; ?>
