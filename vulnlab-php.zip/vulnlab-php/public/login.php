<?php
require __DIR__ . '/_bootstrap.php';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    // --- VULNERABLE ON PURPOSE (challenge: sqli-login) ---
    // Raw string concatenation into a SQL query, no parameter binding.
    // This is the bug the "Authentication Bypass via SQL Injection"
    // challenge asks you to find and exploit. Do not copy this pattern
    // into real code — see includes/db.php and README.md for the fix.
    $pdo = get_db();
    $sql = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
    try {
        $stmt = $pdo->query($sql);
        $user = $stmt ? $stmt->fetch(PDO::FETCH_ASSOC) : false;
    } catch (PDOException $e) {
        $user = false;
        $error = 'Query error (your input broke the SQL syntax — that is itself a clue).';
    }
    // --- END VULNERABLE BLOCK ---

    if ($user) {
        $_SESSION['user'] = $user;
        if (($user['username'] ?? '') === 'admin' || ($user['is_admin'] ?? 0) == 1) {
            mark_solved('sqli-login');
        }
        header('Location: /index.php');
        exit;
    } elseif (!$error) {
        $error = 'Invalid username or password.';
    }
}

$page_title = 'Login';
require __DIR__ . '/../includes/header.php';
?>
<h1>Login</h1>
<?php if (isset($_GET['registered'])): ?><div class="flash success">Account created — log in below.</div><?php endif; ?>
<?php if ($error): ?><div class="flash error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<form method="post">
    <label>Username</label>
    <input type="text" name="username" autocomplete="off">
    <label>Password</label>
    <input type="password" name="password" autocomplete="off">
    <button type="submit">Log in</button>
</form>
<p><a href="/register.php">Need an account? Register</a></p>
<p><a href="/hint.php?challenge=sqli-login">Stuck? See the hint for this login form.</a></p>
<?php require __DIR__ . '/../includes/footer.php'; ?>
