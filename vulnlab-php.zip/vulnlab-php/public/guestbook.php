<?php
require __DIR__ . '/_bootstrap.php';
$user = current_user();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$user) {
        $error = 'Log in to post a message.';
    } else {
        $message = $_POST['message'] ?? '';
        if (trim($message) === '') {
            $error = 'Message cannot be empty.';
        } else {
            $pdo = get_db();
            $pdo->prepare("INSERT INTO guestbook (author, message, created_at) VALUES (?, ?, ?)")
                ->execute([$user['username'], $message, date('c')]);

            if (stripos($message, '<script') !== false || stripos($message, 'onerror=') !== false) {
                mark_solved('xss-stored');
            }
            header('Location: /guestbook.php');
            exit;
        }
    }
}

$pdo = get_db();
$entries = $pdo->query("SELECT * FROM guestbook ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);

$page_title = 'Guestbook';
require __DIR__ . '/../includes/header.php';
?>
<h1>Guestbook</h1>
<p class="lead">Messages here are shown to every visitor, exactly as submitted.</p>
<?php if ($error): ?><div class="flash error"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<?php if ($user): ?>
<form method="post">
    <label>Leave a message</label>
    <textarea name="message" required></textarea>
    <button type="submit">Post</button>
</form>
<?php else: ?>
<p><a href="/login.php">Log in</a> to leave a message.</p>
<?php endif; ?>

<h2>Entries</h2>
<div class="card">
<?php foreach ($entries as $e): ?>
    <div class="guestbook-entry">
        <div class="meta"><?= htmlspecialchars($e['author']) ?> — <?= htmlspecialchars($e['created_at']) ?></div>
        <!-- VULNERABLE ON PURPOSE (challenge: xss-stored): message is
             rendered raw, with no output encoding. Do not copy this
             pattern into real code — see README.md for the fix. -->
        <div><?= $e['message'] ?></div>
    </div>
<?php endforeach; ?>
</div>

<p><a href="/hint.php?challenge=xss-stored">Hint</a></p>
<?php require __DIR__ . '/../includes/footer.php'; ?>
