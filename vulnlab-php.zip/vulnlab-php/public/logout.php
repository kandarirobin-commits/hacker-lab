<?php
require __DIR__ . '/_bootstrap.php';
unset($_SESSION['user']);
session_destroy();
header('Location: /index.php');
exit;
