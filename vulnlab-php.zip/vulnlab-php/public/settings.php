<?php
require __DIR__ . '/_bootstrap.php';
require_login();
$user = current_user();
$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_email = trim($_POST['new_email'] ?? '');
    // VULNERABLE ON PURPOSE (challenge: csrf-settings): this state-changing
    // POST has no CSRF token and is accepted purely because a valid session
    // cookie came along with the request — which a third-party page can
    // trigger automatically. Do not copy this pattern into real code —
    // see README.md for the fix.
    if ($new_email === '' || !filter_var($new_email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Enter a valid email.';
    } else {
        $pdo = get_db();
        $pdo->prepare("UPDATE users SET email = ? WHERE id = ?")->execute([$new_email, $user['id']]);
        $_SESSION['user']['email'] = $new_email;
        $success = 'Email updated.';
        if (!empty($_SERVER['HTTP_REFERER']) && strpos($_SERVER['HTTP_REFERER'], $_SERVER['HTTP_HOST'] ?? "\0") === false) {
            mark_solved('csrf-settings');
        }
    }
}

$page_title = 'Account Settings';
require __DIR__ . '/../includes/header.php';
?>
<h1>Account Settings</h1>
<p class="lead">Current email: <strong><?= htmlspecialchars($user['email']) ?></strong></p>
<?php if ($error): ?><div class="flash error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<?php if ($success): ?><div class="flash success"><?= htmlspecialchars($success) ?></div><?php endif; ?>
<form method="post">
    <label>New email</label>
    <input type="email" name="new_email" required>
    <button type="submit">Update email</button>
</form>
<p class="lead">To solve the CSRF challenge, build a separate external HTML page that auto-submits this form on your behalf while you're logged in here, then open it in a new tab.</p>
<p><a href="/hint.php?challenge=csrf-settings">Hint</a></p>
<?php require __DIR__ . '/../includes/footer.php'; ?>
