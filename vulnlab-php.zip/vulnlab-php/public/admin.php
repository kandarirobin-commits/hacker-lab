<?php
require __DIR__ . '/_bootstrap.php';
require_login();
$user = current_user();

// VULNERABLE ON PURPOSE (challenge: access-control-admin): this page is
// only kept out of the nav menu for non-admins — it does NOT actually
// check is_admin server-side. "Hidden" is not the same as "protected".
// Do not copy this pattern into real code — see README.md for the fix.
if (($user['is_admin'] ?? 0) != 1) {
    mark_solved('access-control-admin');
}

$pdo = get_db();
$users = $pdo->query("SELECT id, username, email, is_admin FROM users ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);

$page_title = 'Admin Panel';
require __DIR__ . '/../includes/header.php';
?>
<h1>🔐 Admin Panel</h1>
<p class="lead">All registered users (this page is meant for administrators only).</p>
<div class="card">
<table style="width:100%; border-collapse: collapse;">
<tr style="text-align:left; color:#9aa3b5;"><th>ID</th><th>Username</th><th>Email</th><th>Admin?</th></tr>
<?php foreach ($users as $u): ?>
<tr>
    <td><?= (int)$u['id'] ?></td>
    <td><?= htmlspecialchars($u['username']) ?></td>
    <td><?= htmlspecialchars($u['email']) ?></td>
    <td><?= $u['is_admin'] ? 'Yes' : 'No' ?></td>
</tr>
<?php endforeach; ?>
</table>
</div>
<p><a href="/hint.php?challenge=access-control-admin">Hint</a></p>
<?php require __DIR__ . '/../includes/footer.php'; ?>
