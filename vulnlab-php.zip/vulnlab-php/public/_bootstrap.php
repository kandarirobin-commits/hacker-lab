<?php
/** Included at the top of every public page. */
session_start();
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/challenges.php';
get_db(); // ensures schema/seed data exist
