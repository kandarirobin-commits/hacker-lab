<?php
require __DIR__ . '/_bootstrap.php';
require_login();

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['avatar'])) {
    $file = $_FILES['avatar'];
    $name = basename($file['name']);
    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));

    // VULNERABLE ON PURPOSE (challenge: upload-unrestricted): this only
    // looks at the client-supplied extension (easily spoofed — it never
    // inspects the actual file content), and stores the upload, under its
    // original name, inside a public directory that the web server will
    // happily execute PHP from. Do not copy this pattern into real code —
    // see README.md for the fix.
    $allowed_hint = ['jpg', 'jpeg', 'png', 'gif', 'php', 'phtml']; // intentionally too permissive
    if (!in_array($ext, $allowed_hint, true)) {
        $error = "Extension .$ext not in the (very loose) allowed hint list.";
    } elseif ($file['error'] !== UPLOAD_ERR_OK) {
        $error = 'Upload failed.';
    } else {
        $dest = __DIR__ . '/uploads/' . $name;
        if (move_uploaded_file($file['tmp_name'], $dest)) {
            $success = "Uploaded to /uploads/$name";
            if (in_array($ext, ['php', 'phtml'], true)) {
                mark_solved('upload-unrestricted');
            }
        } else {
            $error = 'Could not save file.';
        }
    }
}

$page_title = 'Avatar Upload';
require __DIR__ . '/../includes/header.php';
?>
<h1>Avatar Upload</h1>
<p class="lead">Upload an image to use as your avatar.</p>
<?php if ($error): ?><div class="flash error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<?php if ($success): ?><div class="flash success"><?= htmlspecialchars($success) ?> — <a href="/uploads/<?= rawurlencode(basename($_POST['avatar']['name'] ?? '')) ?>">view it</a></div><?php endif; ?>
<form method="post" enctype="multipart/form-data">
    <label>Avatar file</label>
    <input type="file" name="avatar" required>
    <button type="submit">Upload</button>
</form>
<p><a href="/hint.php?challenge=upload-unrestricted">Hint</a></p>
<?php require __DIR__ . '/../includes/footer.php'; ?>
