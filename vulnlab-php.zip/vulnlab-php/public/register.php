<?php
require __DIR__ . '/_bootstrap.php';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $email = trim($_POST['email'] ?? '');
    if ($username === '' || $password === '' || $email === '') {
        $error = 'All fields are required.';
    } else {
        $pdo = get_db();
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->fetch()) {
            $error = 'That username is already taken.';
        } else {
            // Plaintext storage is intentional lab weakness, see db.php note.
            $pdo->prepare("INSERT INTO users (username, password, email, is_admin, bio) VALUES (?, ?, ?, 0, '')")
                ->execute([$username, $password, $email]);
            header('Location: /login.php?registered=1');
            exit;
        }
    }
}
$page_title = 'Register';
require __DIR__ . '/../includes/header.php';
?>
<h1>Create an account</h1>
<?php if ($error): ?><div class="flash error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<form method="post">
    <label>Username</label>
    <input type="text" name="username" required>
    <label>Email</label>
    <input type="email" name="email" required>
    <label>Password</label>
    <input type="password" name="password" required>
    <button type="submit">Register</button>
</form>
<p><a href="/login.php">Already have an account? Log in</a></p>
<?php require __DIR__ . '/../includes/footer.php'; ?>
