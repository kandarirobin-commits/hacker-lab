<?php
require __DIR__ . '/_bootstrap.php';
$id = $_GET['challenge'] ?? '';
$c = get_challenge($id);
$page_title = 'Hint';
require __DIR__ . '/../includes/header.php';
?>
<?php if (!$c): ?>
    <div class="flash error">Unknown challenge.</div>
<?php else: ?>
    <h1>💡 Hint — <?= htmlspecialchars($c['title']) ?></h1>
    <div class="card"><pre class="output"><?= htmlspecialchars($c['hint']) ?></pre></div>
    <div class="actions">
        <a href="<?= htmlspecialchars($c['url']) ?>">← Back to challenge</a>
        <a href="/solution.php?challenge=<?= urlencode($id) ?>">View full solution</a>
        <a href="/index.php">All challenges</a>
    </div>
<?php endif; ?>
<?php require __DIR__ . '/../includes/footer.php'; ?>
