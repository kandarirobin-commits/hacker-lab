<?php
require __DIR__ . '/_bootstrap.php';
require_login();

$result = '';
$error = '';
$submittedUrl = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $submittedUrl = trim($_POST['avatar_url'] ?? '');
    if ($submittedUrl === '') {
        $error = 'Enter a URL.';
    } else {
        // VULNERABLE ON PURPOSE (challenge: ssrf-fetch): the server fetches
        // any URL the user supplies, with no allowlist and no block on
        // loopback/internal addresses, and returns the raw response.
        // Do not copy this pattern into real code — see README.md for the fix.
        $ctx = stream_context_create(['http' => ['timeout' => 5], 'https' => ['timeout' => 5]]);
        $data = @file_get_contents($submittedUrl, false, $ctx);
        if ($data === false) {
            $error = 'Could not fetch that URL.';
        } else {
            $result = $data;
            if (preg_match('#^https?://(127\.0\.0\.1|localhost)#i', $submittedUrl)) {
                mark_solved('ssrf-fetch');
            }
        }
    }
}

$page_title = 'Avatar Fetcher';
require __DIR__ . '/../includes/header.php';
?>
<h1>Avatar Fetcher</h1>
<p class="lead">Give us a URL and we'll fetch it server-side and show you what came back (e.g. to preview a profile picture hosted elsewhere).</p>
<?php if ($error): ?><div class="flash error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<form method="post">
    <label>Image / avatar URL</label>
    <input type="url" name="avatar_url" value="<?= htmlspecialchars($submittedUrl) ?>" placeholder="https://example.com/avatar.png">
    <button type="submit">Fetch</button>
</form>
<?php if ($result !== ''): ?>
<h2>Raw response</h2>
<pre class="output"><?= htmlspecialchars(substr($result, 0, 4000)) ?></pre>
<?php endif; ?>
<p><a href="/hint.php?challenge=ssrf-fetch">Hint</a></p>
<?php require __DIR__ . '/../includes/footer.php'; ?>
