<?php
require __DIR__ . '/_bootstrap.php';
$id = $_GET['challenge'] ?? '';
$c = get_challenge($id);
if ($c) {
    mark_solved($id); // viewing the solution marks it as seen/solved for the dashboard checklist
}
$page_title = 'Solution';
require __DIR__ . '/../includes/header.php';
?>
<?php if (!$c): ?>
    <div class="flash error">Unknown challenge.</div>
<?php else: ?>
    <h1>✅ Solution — <?= htmlspecialchars($c['title']) ?></h1>
    <div class="card"><pre class="output"><?= htmlspecialchars($c['solution']) ?></pre></div>
    <div class="actions">
        <a href="<?= htmlspecialchars($c['url']) ?>">← Back to challenge</a>
        <a href="/index.php">All challenges</a>
    </div>
<?php endif; ?>
<?php require __DIR__ . '/../includes/footer.php'; ?>
