<?php
/** VulnLab-PHP — challenge metadata: title, category, difficulty, hint, solution. */

function get_challenges(): array {
    return [
        'sqli-login' => [
            'title' => 'Authentication Bypass via SQL Injection',
            'category' => 'Injection (SQLi)',
            'difficulty' => 'Easy',
            'url' => '/login.php',
            'description' => 'The login form builds its query by concatenating raw input. Log in as admin without knowing the password.',
            'hint' => "The query looks roughly like:\n  SELECT * FROM users WHERE username = '\$u' AND password = '\$p'\nWhat happens to the query if your username value contains a quote and a SQL comment?",
            'solution' => "Submit username: admin' -- \nand any password. The injected input closes the quoted string and comments out the password check, so the query becomes:\n  SELECT * FROM users WHERE username = 'admin' --' AND password = '...'\nFix: use parameterized queries (PDO prepared statements) everywhere, never concatenate user input into SQL.",
        ],
        'xss-reflected' => [
            'title' => 'Reflected Cross-Site Scripting',
            'category' => 'XSS',
            'difficulty' => 'Easy',
            'url' => '/search.php',
            'description' => 'The search page echoes your query back onto the page without encoding it. Make the page execute arbitrary JavaScript, e.g. pop an alert().',
            'hint' => 'Try searching for a <script> tag or an onerror-bearing <img> tag and see what the page does with it.',
            'solution' => "Search for: <script>alert(document.domain)</script>\nThe search term is echoed into the HTML with no output encoding, so the browser executes it.\nFix: HTML-encode all user-controlled output with htmlspecialchars(), and set a Content-Security-Policy header.",
        ],
        'xss-stored' => [
            'title' => 'Stored Cross-Site Scripting (Guestbook)',
            'category' => 'XSS',
            'difficulty' => 'Medium',
            'url' => '/guestbook.php',
            'description' => 'Guestbook entries are rendered for every visitor without encoding. Plant a payload that runs for anyone who views the page.',
            'hint' => 'Post a message containing an <img> tag with an onerror handler, or a <script> tag, then reload the page as if you were a different visitor.',
            'solution' => "Post a message like: <img src=x onerror=alert('stored-xss')>\nBecause the message is stored and later rendered unescaped for every visitor, the payload executes on every page load, not just yours.\nFix: encode on output (htmlspecialchars), and consider stripping/sanitizing HTML on input with an allowlist library if some formatting is required.",
        ],
        'idor-profile' => [
            'title' => 'Insecure Direct Object Reference',
            'category' => 'Broken Access Control',
            'difficulty' => 'Easy',
            'url' => '/profile.php?id=1',
            'description' => "Log in as alice, then view your own profile. The URL takes a numeric id. Can you view bob's or admin's profile data without authorization?",
            'hint' => 'The id parameter is trusted at face value, with no check that it belongs to the logged-in user. What happens if you just change the number?',
            'solution' => "Change the URL to /profile.php?id=2 or ?id=3 while logged in as alice. The app never checks that the requested id matches the session user, so you can view any account's private bio/email.\nFix: verify server-side that the authenticated user is allowed to access the requested resource (ownership or role check), not just that a session exists.",
        ],
        'access-control-admin' => [
            'title' => 'Broken Access Control — Admin Panel',
            'category' => 'Broken Access Control',
            'difficulty' => 'Easy',
            'url' => '/admin.php',
            'description' => 'The admin panel link is simply hidden from the menu for non-admins — it is not actually access-controlled. Reach it as a regular user.',
            'hint' => 'If a page is only "hidden" by not being linked anywhere, what happens if you type its URL directly while logged in as a non-admin user?',
            'solution' => "Log in as alice or bob and browse directly to /admin.php. The page never checks is_admin server-side, it was only omitted from the nav menu (\"security through obscurity\").\nFix: enforce role checks on every sensitive request server-side, never rely on hiding a link in the UI.",
        ],
        'misconfig-backup' => [
            'title' => 'Security Misconfiguration — Exposed Backup File',
            'category' => 'Security Misconfiguration',
            'difficulty' => 'Easy',
            'url' => '/backup.sql.bak',
            'description' => 'A developer left a database backup file inside the public web root. Find it and see what it leaks.',
            'hint' => 'Think about common backup/editor-swap file names a careless deploy might leave behind in a web root: .bak, .old, .zip, ~, .swp...',
            'solution' => "Request /backup.sql.bak directly. It's a static file sitting in the public web root and contains a full dump of the users table, including plaintext passwords.\nFix: never deploy backups, .env files, or editor swap files inside the public web root; add deploy-time checks / .gitignore rules; disable directory listing.",
        ],
        'ssrf-fetch' => [
            'title' => 'Server-Side Request Forgery',
            'category' => 'SSRF',
            'difficulty' => 'Medium',
            'url' => '/fetch.php',
            'description' => "This page fetches an 'avatar' from any URL you give it and shows you the raw response. The server will fetch any URL you supply, including internal-only addresses.",
            'hint' => 'The server-side fetch has no allowlist. What internal or loopback addresses might the server itself be able to reach that you, as an outside visitor, normally cannot reach directly?',
            'solution' => "Submit a URL like http://127.0.0.1:8000/backup.sql.bak or http://localhost/admin.php as the 'avatar URL'. The server fetches it on your behalf and shows you the response, letting you reach things that aren't meant to be internet-facing (in a real deployment this is how SSRF reaches cloud metadata endpoints, internal admin panels, etc.).\nFix: maintain a strict allowlist of permitted destination hosts/schemes, block loopback/private IP ranges, and never return the raw fetched response to the requester.",
        ],
        'upload-unrestricted' => [
            'title' => 'Unrestricted File Upload',
            'category' => 'Insecure File Upload',
            'difficulty' => 'Medium',
            'url' => '/upload.php',
            'description' => 'The avatar uploader only checks the file extension against an easily-spoofed client-side hint and stores the file as-is in a public, executable directory. What can you upload?',
            'hint' => 'The server trusts the extension in the filename you send and does not re-check the actual file content, nor does it stop PHP files from being placed in a public, script-executing directory.',
            'solution' => "Upload a file named something like shell.php containing a small PHP snippet (e.g. <?php echo \"uploaded-ok\"; ?>), then visit /uploads/shell.php directly to see it execute. In a real attack this becomes remote code execution.\nFix: validate file content (not just extension/MIME header, which are attacker-controlled), store uploads outside the web root or in a non-executable location, randomize stored filenames, and serve them with a content-disposition that prevents execution.",
        ],
        'csrf-settings' => [
            'title' => 'Cross-Site Request Forgery',
            'category' => 'CSRF',
            'difficulty' => 'Medium',
            'url' => '/settings.php',
            'description' => "The 'change email' form has no CSRF token. Craft an external HTML page that, when visited by a logged-in victim, silently changes their email.",
            'hint' => 'The form submits a plain POST with no per-session token the server checks. Could an auto-submitting form on another page achieve the same POST while riding the victim\'s existing session cookie?',
            'solution' => "Build a standalone HTML file with a form posting to http://localhost:8000/settings.php with a new_email field, and auto-submit it with JS (or just a styled button). If a logged-in victim loads that page, their email gets changed without their intent, because the server only checks the session cookie (sent automatically by the browser) and never a CSRF token.\nFix: include a per-session, per-form CSRF token, validate it server-side on every state-changing POST, and set the session cookie's SameSite attribute to Lax or Strict.",
        ],
    ];
}

function get_challenge(string $id): ?array {
    $all = get_challenges();
    return $all[$id] ?? null;
}
