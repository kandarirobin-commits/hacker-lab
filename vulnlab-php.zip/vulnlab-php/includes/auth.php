<?php
/** VulnLab-PHP — minimal session helpers. */

function current_user(): ?array {
    return $_SESSION['user'] ?? null;
}

function require_login(): void {
    if (!current_user()) {
        header('Location: /login.php');
        exit;
    }
}

function mark_solved(string $challenge_id): void {
    $pdo = get_db();
    $stmt = $pdo->prepare("INSERT OR REPLACE INTO progress (challenge_id, solved_at) VALUES (?, ?)");
    $stmt->execute([$challenge_id, date('c')]);
}

function is_solved(string $challenge_id): bool {
    $pdo = get_db();
    $stmt = $pdo->prepare("SELECT 1 FROM progress WHERE challenge_id = ?");
    $stmt->execute([$challenge_id]);
    return (bool) $stmt->fetchColumn();
}
