</main>
<footer class="site-footer">
    <p>VulnLab-PHP — intentionally vulnerable training app. For use in isolated/local environments only.</p>
</footer>
</body>
</html>
