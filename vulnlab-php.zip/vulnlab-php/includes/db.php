<?php
/**
 * VulnLab-PHP — database bootstrap.
 *
 * Uses SQLite so the whole lab runs with zero external services:
 * just `php -S localhost:8000 -t public`. The schema and seed data
 * are (re)created automatically on first run.
 *
 * NOTE: This file intentionally powers a deliberately vulnerable
 * training application. Do not reuse these patterns in real projects.
 */

define('DB_PATH', __DIR__ . '/../data/vulnlab.sqlite');

function get_db(): PDO {
    static $pdo = null;
    if ($pdo !== null) {
        return $pdo;
    }

    $needs_init = !file_exists(DB_PATH);
    $pdo = new PDO('sqlite:' . DB_PATH);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if ($needs_init) {
        init_schema($pdo);
    }

    return $pdo;
}

function init_schema(PDO $pdo): void {
    $pdo->exec("
        CREATE TABLE users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            email TEXT NOT NULL,
            is_admin INTEGER NOT NULL DEFAULT 0,
            bio TEXT DEFAULT ''
        );
    ");

    $pdo->exec("
        CREATE TABLE guestbook (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            author TEXT NOT NULL,
            message TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
    ");

    $pdo->exec("
        CREATE TABLE progress (
            challenge_id TEXT PRIMARY KEY,
            solved_at TEXT
        );
    ");

    // Seed users. Passwords are stored in plaintext ON PURPOSE —
    // that's part of what a learner is meant to discover/exploit
    // in this lab, never do this in a real application.
    $stmt = $pdo->prepare("INSERT INTO users (username, password, email, is_admin, bio) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute(['alice', 'alice123', 'alice@vulnlab.test', 0, 'I like gardening and CTFs.']);
    $stmt->execute(['bob', 'bobpass', 'bob@vulnlab.test', 0, 'Coffee enthusiast.']);
    $stmt->execute(['admin', 'S3cretAdminPW!', 'admin@vulnlab.test', 1, 'System administrator.']);

    $pdo->prepare("INSERT INTO guestbook (author, message, created_at) VALUES (?, ?, ?)")
        ->execute(['system', 'Welcome to the VulnLab guestbook! Sign in and leave a note.', date('c')]);
}
