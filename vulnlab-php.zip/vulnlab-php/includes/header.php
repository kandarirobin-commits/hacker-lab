<?php
/** VulnLab-PHP — shared page header. Expects $page_title to optionally be set. */
$user = current_user();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= htmlspecialchars($page_title ?? 'VulnLab-PHP') ?></title>
<link rel="stylesheet" href="/css/style.css">
</head>
<body>
<header class="site-header">
    <a class="brand" href="/index.php">🧪 VulnLab-PHP</a>
    <nav>
        <a href="/index.php">Challenges</a>
        <a href="/guestbook.php">Guestbook</a>
        <a href="/search.php">Search</a>
        <?php if ($user): ?>
            <a href="/profile.php?id=<?= (int)$user['id'] ?>">My Profile</a>
            <a href="/settings.php">Settings</a>
            <a href="/upload.php">Upload</a>
            <a href="/fetch.php">Fetcher</a>
            <a href="/logout.php">Logout (<?= htmlspecialchars($user['username']) ?>)</a>
        <?php else: ?>
            <a href="/login.php">Login</a>
            <a href="/register.php">Register</a>
        <?php endif; ?>
    </nav>
</header>
<main class="container">
