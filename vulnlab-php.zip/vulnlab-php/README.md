# VulnLab-PHP

**A deliberately vulnerable PHP web application for hands-on ethical hacking practice.**

VulnLab-PHP is a small, self-contained training target in the spirit of
DVWA / OWASP Juice Shop / WebGoat. It ships with nine challenges covering
the OWASP Top 10 core classes, each with a real (not simulated) bug to
exploit, a hint, and a full solution writeup with a remediation note.

> ⚠️ **This application is intentionally insecure.** Every bug described
> below is real and exploitable by design. Run it **only** on `localhost`
> or an isolated lab network you control. Never deploy it to a shared
> server, a public cloud instance with an open port, or any
> internet-reachable host.

---

## Challenges included

| Challenge | Category | Difficulty |
|---|---|---|
| Authentication Bypass via SQL Injection | Injection (SQLi) | Easy |
| Reflected Cross-Site Scripting | XSS | Easy |
| Stored Cross-Site Scripting (Guestbook) | XSS | Medium |
| Insecure Direct Object Reference | Broken Access Control | Easy |
| Broken Access Control — Admin Panel | Broken Access Control | Easy |
| Security Misconfiguration — Exposed Backup File | Security Misconfiguration | Easy |
| Server-Side Request Forgery | SSRF | Medium |
| Unrestricted File Upload | Insecure File Upload | Medium |
| Cross-Site Request Forgery | CSRF | Medium |

Each challenge page in the app links to its own **Hint** and **Solution**
writeup, and the dashboard tracks which ones you've viewed/solved.

---

## Requirements

- PHP 8.0+ with the `pdo_sqlite` extension (bundled with PHP by default
  on virtually every distro and the official Docker images)
- A terminal — no external database server needed
- *(Optional)* Docker + Docker Compose, if you'd rather containerize it

No Composer packages or other third-party dependencies are required —
see [`requirements.txt`](./requirements.txt).

---

## Installation

### Option A — Run directly with PHP's built-in server (fastest)

```bash
# 1. Get the project
git clone https://github.com/<your-username>/vulnlab-php.git
cd vulnlab-php

# 2. Check PHP is installed with SQLite support
php -v
php -m | grep -i sqlite      # should list pdo_sqlite and/or sqlite3

# If missing, install it, e.g. on Debian/Ubuntu/Kali:
sudo apt update && sudo apt install php php-sqlite3

# 3. Start the app (binds to localhost only)
php -S 127.0.0.1:8000 -t public
```

Then open **http://127.0.0.1:8000/** in your browser. The SQLite
database and schema are created automatically on first request.

### Option B — Run with Docker Compose

```bash
git clone https://github.com/<your-username>/vulnlab-php.git
cd vulnlab-php
docker compose up --build
```

This builds a `php:8.3-cli` image and runs the same built-in server
inside the container, with the port bound to `127.0.0.1:8000` on the
host only (see `docker-compose.yml` — do not change this to `0.0.0.0`
unless you fully understand the exposure).

Stop it with `Ctrl+C`, or `docker compose down`.

### Resetting the lab

To wipe all progress, accounts, and guestbook posts and start fresh:

```bash
rm -f data/vulnlab.sqlite
rm -f public/uploads/*   # remove anything you uploaded, e.g. during the upload challenge
```

The database is recreated with the default seed accounts on the next request.

---

## Usage

1. Visit `http://127.0.0.1:8000/` for the challenge dashboard.
2. Register your own account, or use a seed account: `alice / alice123` or
   `bob / bobpass`.
3. Work through the challenges in any order. Each has:
   - A short description of what to achieve
   - A **Hint** if you get stuck
   - A full **Solution** writeup (viewing it marks the challenge solved
     on your dashboard)
4. For the **CSRF** challenge, there's an example attacker page at
   `csrf-poc/evil-page.html` — serve it on a different port
   (`cd csrf-poc && php -S localhost:9000`) to see the cross-origin
   attack actually work against your own logged-in session.

---

## Project structure

```
vulnlab-php/
├── public/                 # web root — only this folder is served
│   ├── index.php            # challenge dashboard
│   ├── login.php            # SQLi challenge
│   ├── search.php           # reflected XSS challenge
│   ├── guestbook.php        # stored XSS challenge
│   ├── profile.php          # IDOR challenge
│   ├── admin.php            # broken access control challenge
│   ├── backup.sql.bak       # security misconfiguration challenge
│   ├── fetch.php            # SSRF challenge
│   ├── upload.php           # unrestricted file upload challenge
│   ├── settings.php         # CSRF challenge
│   ├── hint.php / solution.php
│   ├── uploads/             # where uploaded files land (see challenge)
│   └── css/style.css
├── includes/                # db bootstrap, session helpers, challenge metadata
├── csrf-poc/evil-page.html  # example attacker page for the CSRF challenge
├── data/                    # SQLite DB file lives here (gitignored)
├── Dockerfile / docker-compose.yml
├── requirements.txt
├── LICENSE
└── README.md
```

---

## How the vulnerabilities are marked in the code

Every intentionally vulnerable block of code is wrapped in a comment like:

```php
// --- VULNERABLE ON PURPOSE (challenge: sqli-login) ---
...
// --- END VULNERABLE BLOCK ---
```

so you can grep for `VULNERABLE ON PURPOSE` to find every planted bug and
read why it's broken, directly in context. Each challenge's solution
writeup (in `includes/challenges.php`) also states the concrete fix —
e.g. parameterized queries for the SQLi challenge, output encoding for
the XSS challenges, ownership/role checks for the access-control
challenges, CSRF tokens for the CSRF challenge, content-based validation
and non-executable storage for the upload challenge, and a destination
allowlist for the SSRF challenge.

---

## Safety notes

- **Do not expose this app to the internet or an untrusted network.**
  It has no protections of any kind — that's the point.
- Passwords are stored in plaintext in the database on purpose — part of
  what you can discover via the misconfiguration/SQLi challenges.
- The file upload challenge lets you upload and execute PHP files in a
  public directory, i.e. it's a working (contained, local-only) remote
  code execution primitive by design.
- Treat the whole app as hostile to itself: it exists to be broken.

## License

MIT — see [LICENSE](./LICENSE). Includes an additional project-policy
clause restricting deployment to isolated/local lab environments.

## References

- [OWASP Top 10](https://owasp.org/www-project-top-ten/)
- [OWASP Web Security Testing Guide](https://owasp.org/www-project-web-security-testing-guide/)
- [PortSwigger Web Security Academy](https://portswigger.net/web-security) — great for deeper dives on each vuln class
